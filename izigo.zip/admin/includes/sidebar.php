<div class="container-fluid-full">
<div class="row-fluid">
		
	<!-- start: Main Menu -->
	<div id="sidebar-left" class="span2">
		<div class="nav-collapse sidebar-nav">
			<ul class="nav nav-tabs nav-stacked main-menu">
				<li><a href="index.php"><i class="icon-dashboard"></i><span class="hidden-tablet"> Tableau de bord</span></a></li>
				<li><a href="message.php"><i class="icon-user"></i><span class="hidden-tablet"> Messages </span></a></li>
				<!-- <li><a href="usersrendezvous.php"><i class="icon-user"></i><span class="hidden-tablet"> Rendez-vous users</span></a></li>
                
						 -->
				</lim>
				<li><a href="logout.php"><i class="icon-off"></i><span class="hidden-tablet"> Déconnexion</span></a></li>

			</ul>
		</div>
	</div>